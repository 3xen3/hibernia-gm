/* Hibernia GM Bağlantısı
   Hibernia GM Ekranı web sitesi ile Foundry VTT arasında köprü: zar, resim gösterme, karşılaşma kurma,
   karakter ve NPC aktarımı, dosya alışverişi ve Korku eşitlemesi.
   Telif: tüm hakları saklıdır. Özel kullanım içindir. */
const MOD = "hibernia-gm-baglanti";
const SBV = "2.117.3";
const CDN = [
  `https://cdn.jsdelivr.net/npm/@supabase/supabase-js@${SBV}/dist/umd/supabase.js`,
  `https://unpkg.com/@supabase/supabase-js@${SBV}/dist/umd/supabase.js`
];
const DEF_URL = "https://klpntbzhzcgfmqmksvgw.supabase.co";
const DEF_KEY = "sb_publishable_hsep_JfWjHkRVeVVqJLX8A_5dVCTsSC";
const BUCKET = "hibernia";
const MIN5 = 5 * 60e3, H6 = 6 * 3600e3;

const H = { sb: null, uid: null, email: "", chan: null, beat: null, state: "kapalı", err: "", log: [], done: new Set(), q: Promise.resolve(),
  fearFromSite: null, fearTimer: null, dirs: new Set(), listing: {}, app: null, authSub: null, starting: false };

/* ---------- küçük yardımcılar ---------- */
const gen = () => game.release?.generation ?? 12;
const isLeader = () => !!game.user?.isGM && (!game.users?.activeGM || game.users.activeGM.id === game.user.id);
const int = (v, d = 0) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const md = s => esc(s).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br>");
const para = s => String(s || "").trim() ? String(s).split(/\n{2,}/).map(p => `<p>${md(p.trim())}</p>`).join("") : "";
const strip = h => { const d = document.createElement("div"); d.innerHTML = String(h || ""); return (d.textContent || "").replace(/\s+\n/g, "\n").trim(); };
const safe = n => String(n || "dosya").normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/ı/g, "i").replace(/İ/g, "I").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(-90) || "dosya";
const showName = n => String(n || "").split("/").pop().replace(/^[a-z0-9]{6,9}-/, "");
const setting = k => { try { return game.settings.get(MOD, k); } catch (e) { return undefined; } };
const FP = () => foundry.applications?.apps?.FilePicker?.implementation ?? globalThis.FilePicker;
const isDH = () => game.system?.id === "daggerheart";
const hasType = (doc, t) => !!(CONFIG[doc]?.dataModels?.[t] || game.system?.documentTypes?.[doc]?.[t] || (game.documentTypes?.[doc] || []).includes?.(t));
function fileSource() {
  const s = setting("source");
  if (s && s !== "auto") return s;
  return (typeof ForgeVTT !== "undefined" && ForgeVTT.usingTheForge) ? "forgevtt" : "data";
}
const baseDir = () => String(setting("folder") || "hibernia").replace(/^\/+|\/+$/g, "") || "hibernia";
function note(msg, type = "info") { try { ui.notifications?.[type]?.("Hibernia: " + msg); } catch (e) {} }
function log(dir, kind, text, ok = true) {
  H.log.unshift({ t: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }), dir, kind, text: String(text || "").slice(0, 160), ok });
  H.log = H.log.slice(0, 30); H.app?.refresh();
}
function setState(state, err = "") { H.state = state; H.err = err; H.app?.refresh(); }
const KIND_TR = { roll: "Zar", show_image: "Resim", encounter: "Karşılaşma", actors: "Karakter/NPC", file: "Dosya", fear: "Korku", actor: "Aktör" };

/* ---------- Supabase ---------- */
async function loadSupabase() {
  if (window.supabase?.createClient) return window.supabase;
  for (const src of CDN) {
    try {
      await new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.async = true; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
      if (window.supabase?.createClient) return window.supabase;
    } catch (e) { /* sonraki kaynağı dene */ }
  }
  throw new Error("Bağlantı kitaplığı yüklenemedi (internet ya da engelleyici).");
}
async function client() {
  if (H.sb) return H.sb;
  const lib = await loadSupabase();
  H.sb = lib.createClient(setting("url") || DEF_URL, setting("key") || DEF_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storageKey: "hibernia-gm-foundry-auth" }
  });
  H.authSub = H.sb.auth.onAuthStateChange((ev, session) => {
    if (ev === "SIGNED_OUT") stop("giriş gerekli");
    else if ((ev === "SIGNED_IN" || ev === "TOKEN_REFRESHED") && session && session.user && H.uid !== session.user.id) setTimeout(() => start(session.user), 0);
  });
  return H.sb;
}
async function connect() {
  if (!game.user?.isGM) return;
  try {
    setState("bağlanıyor");
    const sb = await client();
    const { data } = await sb.auth.getSession();
    if (!data?.session) { setState("giriş gerekli"); return; }
    await start(data.session.user);
  } catch (e) { console.error(MOD, e); setState("hata", e.message || String(e)); }
}
async function start(user) {
  if (H.starting || (H.uid === user.id && H.chan)) return;
  H.starting = true;
  try {
    H.uid = user.id; H.email = user.email || "";
    if (H.chan) { try { await H.sb.removeChannel(H.chan); } catch (e) {} }
    H.chan = H.sb.channel("hib-foundry-" + H.uid)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "vtt_events", filter: "user_id=eq." + H.uid }, m => {
        const r = m.new; if (r && r.source === "site") queue(r, {});
      })
      .subscribe(status => {
        if (status === "SUBSCRIBED") { setState("bağlı"); processPending(); }
        else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") setState("bağlantı sorunu", "Canlı kanal kurulamadı; birkaç saniye içinde yeniden denenecek.");
      });
    clearInterval(H.beat); H.beat = setInterval(heartbeat, 60e3); heartbeat();
    setState("bağlı");
  } finally { H.starting = false; }
}
function stop(state) {
  clearInterval(H.beat); H.beat = null;
  if (H.chan && H.sb) { try { H.sb.removeChannel(H.chan); } catch (e) {} }
  H.chan = null; H.uid = null; H.email = ""; setState(state);
}
async function heartbeat() {
  if (!H.uid || !isLeader()) return;
  const data = { at: Date.now(), world: game.world?.title || "", system: game.system?.id || "", systemVersion: game.system?.version || "", core: game.version || "",
    module: game.modules.get(MOD)?.version || "", scene: canvas?.scene?.name || "", users: game.users.filter(u => u.active).map(u => u.name), gm: game.user.name };
  try { await H.sb.from("gm_state").upsert({ user_id: H.uid, part: "foundry", data, updated_at: new Date().toISOString() }); } catch (e) { console.warn(MOD, e); }
}
async function send(kind, payload) {
  if (!H.uid) { note("Önce Hibernia penceresinden giriş yap.", "warn"); return null; }
  const { data, error } = await H.sb.from("vtt_events").insert({ source: "foundry", kind, payload }).select("id").single();
  if (error) { note("Siteye gönderilemedi: " + error.message, "error"); log("çıkış", kind, error.message, false); return null; }
  log("çıkış", kind, payload.name || payload.formula || payload.value || "");
  return data;
}

/* ---------- olay kuyruğu ---------- */
function queue(r, opts) { H.q = H.q.then(() => handle(r, opts)).catch(e => console.error(MOD, e)); return H.q; }
async function processPending() {
  if (!H.uid || !isLeader()) return;
  const since = new Date(Date.now() - 7 * 864e5).toISOString();
  const { data, error } = await H.sb.from("vtt_events").select("*").eq("source", "site").is("done_at", null).gte("created_at", since).order("id", { ascending: true }).limit(200);
  if (error) { console.warn(MOD, error); return; }
  const fears = (data || []).filter(r => r.kind === "fear");
  const lastFearId = fears.length ? fears[fears.length - 1].id : null;
  for (const r of data || []) queue(r, { pending: true, lastFearId });
}
async function handle(r, opts) {
  if (!isLeader() || !H.uid || H.done.has(r.id)) return;
  H.done.add(r.id);
  const age = Date.now() - Date.parse(r.created_at);
  let skip = null;
  if (age > H6) skip = "süresi geçti (6 saatten eski)";
  else if ((r.kind === "roll" || r.kind === "show_image") && age > MIN5) skip = "eski olduğu için atlandı";
  else if (r.kind === "fear" && opts.lastFearId && r.id !== opts.lastFearId) skip = "daha yeni bir Korku değeri vardı";
  const claim = await H.sb.from("vtt_events").update({ done_at: new Date().toISOString(), result: { durum: "işleniyor" } }).eq("id", r.id).is("done_at", null).select("id");
  if (claim.error || !claim.data?.length) return;
  let result;
  try {
    const fn = HANDLERS[r.kind];
    result = skip ? { atlandi: skip } : fn ? await fn(r.payload || {}) : { atlandi: "bilinmeyen olay türü" };
    log("giriş", r.kind, (result && (result.ozet || result.atlandi)) || "", true);
  } catch (e) {
    console.error(MOD, e); result = { error: e.message || String(e) };
    log("giriş", r.kind, result.error, false); note(`${KIND_TR[r.kind] || r.kind} işlenemedi: ${result.error}`, "error");
  }
  await H.sb.from("vtt_events").update({ result: result || { ok: true } }).eq("id", r.id);
}

/* ---------- dosyalar ---------- */
async function ensureDir(dir) {
  if (H.dirs.has(dir)) return;
  const parts = dir.split("/"); let cur = "";
  for (const p of parts) {
    cur = cur ? cur + "/" + p : p;
    if (H.dirs.has(cur)) continue;
    try { await FP().browse(fileSource(), cur); } catch (e) { try { await FP().createDirectory(fileSource(), cur, {}); } catch (e2) { /* zaten var */ } }
    H.dirs.add(cur);
  }
}
async function existing(dir, name) {
  if (!H.listing[dir]) { try { const r = await FP().browse(fileSource(), dir); H.listing[dir] = (r.files || []).map(String); } catch (e) { H.listing[dir] = []; } }
  return H.listing[dir].find(f => decodeURIComponent(f.split("?")[0]).endsWith("/" + name)) || null;
}
async function storageBlob(path) {
  const { data, error } = await H.sb.storage.from(BUCKET).download(path);
  if (error || !data) throw new Error("dosya depodan indirilemedi" + (error ? ": " + error.message : ""));
  return data;
}
/** Sitedeki özel depodan bir dosyayı Foundry veri klasörüne kopyalar; Foundry'deki yolu döndürür. */
async function toFoundry({ path, url }, sub, name) {
  const dir = `${baseDir()}/${sub}`;
  await ensureDir(dir);
  name = safe(name || showName(path || url));
  const have = await existing(dir, name);
  if (have) return have;
  let blob;
  if (path) blob = await storageBlob(path);
  else { const res = await fetch(url); if (!res.ok) throw new Error("dosya indirilemedi (" + res.status + ")"); blob = await res.blob(); }
  const file = new File([blob], name, { type: blob.type || "application/octet-stream" });
  const r = await FP().upload(fileSource(), dir, file, {}, { notify: false });
  if (!r || r.status !== "success") throw new Error((r && r.message) || "Foundry'ye yüklenemedi (dosya yükleme izni?)");
  const out = r.path || `${dir}/${name}`;
  (H.listing[dir] = H.listing[dir] || []).push(out);
  return out;
}
const imgName = (key, path) => safe(String(key || "resim").replace(/[:/]/g, "-")) + "-" + safe(showName(path)).replace(/^.*?([a-z0-9]{4,8})\.(\w+)$/i, "$1.$2");

/* ---------- belgeler ---------- */
async function ensureFolder(name, type) {
  return game.folders.find(f => f.type === type && f.name === name) || await Folder.implementation.create({ name, type, color: "#7a1f26" });
}
async function ensureJournal(name) {
  const folder = await ensureFolder("Hibernia", "JournalEntry");
  return game.journal.find(j => j.name === name) || await JournalEntry.implementation.create({ name, folder: folder.id, ownership: { default: 0 } });
}
async function upsertPage(journal, name, data) {
  const p = journal.pages.find(x => x.name === name);
  if (p) { await p.update(data); return p; }
  const [np] = await journal.createEmbeddedDocuments("JournalEntryPage", [Object.assign({ name }, data)]);
  return np;
}
async function showImage(src, title) {
  const IP = foundry.applications?.apps?.ImagePopout;
  if (IP && foundry.applications?.api?.ApplicationV2 && IP.prototype instanceof foundry.applications.api.ApplicationV2) {
    const ip = new IP({ src, window: { title: title || "Hibernia" }, caption: title || "", showTitle: true });
    await ip.render({ force: true });
    if (typeof ip.shareImage === "function") ip.shareImage();
    else game.socket.emit("shareImage", { image: src, title: title || "", caption: title || "", uuid: null, showTitle: true });
  } else {
    const ip = new ImagePopout(src, { title: title || "Hibernia", shareable: true });
    ip.render(true); ip.shareImage();
  }
}

/* ---------- Daggerheart eşlemesi ---------- */
const RANGES = [[/^(melee|yak[ıi]n d[öo]v[üu]ş)/i, "melee"], [/^(very close|[çc]ok yak[ıi]n)/i, "veryClose"], [/^(close|yak[ıi]n)/i, "close"], [/^(very far|[çc]ok uzak)/i, "veryFar"], [/^(far|uzak)/i, "far"]];
const rangeId = r => { const s = String(r || "").trim(); for (const [re, id] of RANGES) if (re.test(s)) return id; return null; };
function parseDmg(s) {
  const t = String(s || "").trim();
  const type = /\bmag|büyü/i.test(t) ? "magical" : "physical";
  const m = t.match(/(\d*)\s*d\s*(4|6|8|10|12|20)\s*(?:([+-])\s*(\d+))?/i);
  if (m) return { n: int(m[1], 1) || 1, dice: "d" + m[2], bonus: m[3] ? int(m[3] + m[4], 0) : null, type };
  const f = t.match(/^\d+/);
  return { formula: f ? f[0] : "1", type };
}
function parseExp(s) {
  const out = []; const re = /([^,;]+?)\s*([+-]\s*\d+)/g; let m;
  while ((m = re.exec(String(s || "")))) out.push({ name: m[1].trim(), value: int(m[2].replace(/\s/g, ""), 1) });
  return out;
}
function featForm(k) { const s = String(k || ""); return /tepki|reaction/i.test(s) ? "reaction" : /hamle|action|fear|korku|stres|stress/i.test(s) ? "action" : "passive"; }
function advType(t) {
  const types = CONFIG.DH?.ACTOR?.allAdversaryTypes ?? CONFIG.DH?.ACTOR?.adversaryTypes ?? {};
  const k = String(t || "standard").toLowerCase().split(/[\s(/]/)[0];
  return k in types ? k : "standard";
}
function dhCreatureSystem(u, fresh) {
  const sys = {
    tier: clamp(int(u.tier, 1), 1, 4), type: advType(u.type), difficulty: int(u.diff, 10),
    damageThresholds: { major: int(u.mj, 0), severe: int(u.sv, 0) },
    resources: { hitPoints: { value: clamp(int(u.hpMarked, 0), 0, 99), max: Math.max(1, int(u.hp, 1)) }, stress: { value: clamp(int(u.stMarked, 0), 0, 99), max: Math.max(0, int(u.st, 0)) } },
    motivesAndTactics: u.mot || "", description: para(u.desc), notes: u.notesHTML ?? para(u.note)
  };
  if (fresh) { const ex = {}; parseExp(u.exp).forEach(e => { ex[foundry.utils.randomID()] = { name: e.name, value: e.value, description: "" }; }); sys.experiences = ex; }
  return sys;
}
async function applyAttack(actor, u) {
  const src = actor._source?.system?.attack; if (!src) return;
  const dm = parseDmg(u.dmg);
  const val = dm.dice ? { multiplier: "flat", flatMultiplier: dm.n, dice: dm.dice, bonus: dm.bonus, custom: { enabled: false, formula: "" } }
    : { multiplier: "flat", flatMultiplier: 1, dice: "d6", bonus: null, custom: { enabled: true, formula: dm.formula } };
  const upd = { "system.attack.name": u.wpn || "Saldırı" };
  const rg = rangeId(u.rng); if (rg) upd["system.attack.range"] = rg;
  const b = int(String(u.atk || "").replace(/[^\d-]/g, ""), NaN); if (Number.isFinite(b)) upd["system.attack.roll.bonus"] = b;
  const dmg = src.damage || {};
  const part = old => foundry.utils.mergeObject(foundry.utils.deepClone(old || { applyTo: "hitPoints" }), { applyTo: "hitPoints", value: val, type: [dm.type] }, { inplace: false });
  if (dmg.parts && typeof dmg.parts === "object" && !Array.isArray(dmg.parts)) {
    const key = Object.keys(dmg.parts).find(k => dmg.parts[k]?.applyTo === "hitPoints") || "hitPoints";
    upd[`system.attack.damage.parts.${key}`] = part(dmg.parts[key]);
  } else if ("main" in dmg) upd["system.attack.damage.main"] = part(dmg.main);
  try { await actor.update(upd); } catch (e) { console.warn(MOD, "saldırı güncellenemedi", e); }
}
async function setFeatures(actor, feats) {
  if (!hasType("Item", "feature")) return;
  const old = actor.items.filter(i => i.getFlag(MOD, "feat")).map(i => i.id);
  if (old.length) await actor.deleteEmbeddedDocuments("Item", old);
  const items = (feats || []).filter(f => f && f[0]).map(f => ({
    name: String(f[0]), type: "feature", img: "icons/svg/book.svg",
    system: { description: `${f[1] ? `<p><em>${esc(f[1])}</em></p>` : ""}${para(f[2])}`, featureForm: featForm(f[1]) },
    flags: { [MOD]: { feat: true } }
  }));
  if (items.length) await actor.createEmbeddedDocuments("Item", items);
}
function statCardHTML(u) {
  const row = (k, v) => v || v === 0 ? `<tr><th>${esc(k)}</th><td>${md(v)}</td></tr>` : "";
  return `<table>${row("Kademe", u.tier)}${row("Tür", u.type)}${row("Zorluk", u.diff)}${row("Eşikler", u.mj || u.sv ? `${u.mj}/${u.sv}` : "")}${row("HP", u.hp)}${row("Stres", u.st)}${row("Saldırı", [u.atk, u.wpn, u.rng, u.dmg].filter(Boolean).join(" · "))}${row("Deneyim", u.exp)}</table>${(u.feats || []).map(f => `<p><strong>${esc(f[0])}</strong>${f[1] ? ` <em>(${esc(f[1])})</em>` : ""}: ${md(f[2])}</p>`).join("")}`;
}
async function imgFor(u) {
  if (!u.img) return null;
  try { return await toFoundry({ path: u.img }, "resim", imgName(u.key, u.img)); } catch (e) { console.warn(MOD, "resim alınamadı", e); return null; }
}
/** Sistem bir alanı kabul etmezse önce kaynakları, sonra sistem verisini bırakarak yeniden dener. */
async function safeCreate(data) {
  try { return await Actor.implementation.create(data); }
  catch (e) {
    console.warn(MOD, "aktör tam veriyle oluşturulamadı, sadeleştiriliyor", e);
    const d = foundry.utils.deepClone(data);
    if (d.system?.resources) { delete d.system.resources; try { return await Actor.implementation.create(d); } catch (e2) {} }
    delete d.system; return await Actor.implementation.create(d);
  }
}
async function safeUpdate(actor, data) {
  try { return await actor.update(data); }
  catch (e) { console.warn(MOD, e); const d = foundry.utils.deepClone(data); delete d.system; return await actor.update(d); }
}
/** Düşman ya da NPC aktörünü oluşturur veya aynı anahtarla gelmişse günceller. */
async function upsertCreature(u, folderName) {
  const folder = await ensureFolder(folderName, "Actor");
  const key = `${u.src || "site"}:${u.base || u.name}`;
  const img = await imgFor(u);
  let actor = game.actors.find(a => a.getFlag(MOD, "key") === key);
  const name = u.base || u.name;
  if (!isDH()) {
    const type = hasType("Actor", "npc") ? "npc" : (Object.keys(CONFIG.Actor?.dataModels || {})[0] || game.system?.documentTypes?.Actor && Object.keys(game.system.documentTypes.Actor)[0] || "npc");
    if (!actor) actor = await Actor.implementation.create({ name, type, folder: folder.id, img: img || undefined, flags: { [MOD]: { key } }, prototypeToken: { name, disposition: -1, texture: img ? { src: img } : undefined } });
    const j = await ensureJournal("Hibernia · Stat blokları");
    await upsertPage(j, name, { type: "text", text: { content: statCardHTML(u), format: 1 } });
    return actor;
  }
  const type = u.kind === "env" && hasType("Actor", "environment") ? "environment" : "adversary";
  const sys = dhCreatureSystem(u, !actor);
  if (type === "environment") { delete sys.damageThresholds; delete sys.resources; delete sys.experiences; delete sys.type; sys.impulses = u.mot || ""; delete sys.motivesAndTactics; }
  const base = { name, img: img || undefined, system: sys };
  if (img) base.prototypeToken = { texture: { src: img } };
  if (actor) await safeUpdate(actor, base);
  else actor = await safeCreate(Object.assign(base, { type, folder: folder.id, flags: { [MOD]: { key } },
    prototypeToken: Object.assign({ name, disposition: CONST.TOKEN_DISPOSITIONS.HOSTILE, actorLink: false }, img ? { texture: { src: img } } : {}) }));
  if (type === "adversary") await applyAttack(actor, u);
  await setFeatures(actor, u.feats);
  return actor;
}
async function placeTokens(scene, list) {
  const g = scene.grid?.size || 100;
  const onCanvas = canvas?.scene?.id === scene.id && canvas.stage;
  const cx = onCanvas ? canvas.stage.pivot.x : (scene.dimensions?.width || scene.width || 2000) / 2;
  const cy = onCanvas ? canvas.stage.pivot.y : (scene.dimensions?.height || scene.height || 2000) / 2;
  const cols = Math.max(1, Math.ceil(Math.sqrt(list.length)));
  const data = [];
  for (let i = 0; i < list.length; i++) {
    const { u, actor } = list[i];
    const x = Math.round((cx + ((i % cols) - cols / 2) * g) / g) * g, y = Math.round((cy + (Math.floor(i / cols) - cols / 2) * g) / g) * g;
    const td = await actor.getTokenDocument({ name: u.name, x, y, disposition: CONST.TOKEN_DISPOSITIONS.HOSTILE, actorLink: false });
    data.push(td.toObject());
  }
  const created = await scene.createEmbeddedDocuments("Token", data);
  for (let i = 0; i < created.length; i++) {
    const u = list[i].u;
    if ((int(u.hpMarked) || int(u.stMarked)) && created[i].actor && isDH()) {
      try { await created[i].actor.update({ "system.resources.hitPoints.value": int(u.hpMarked), "system.resources.stress.value": int(u.stMarked) }); } catch (e) {}
    }
  }
  return created;
}
async function addToCombat(scene, tokens) {
  let combat = game.combats.find(c => (c.scene?.id ?? c.scene) === scene.id && c.active) || game.combats.find(c => (c.scene?.id ?? c.scene) === scene.id);
  if (!combat) combat = await Combat.implementation.create({ scene: scene.id, active: true });
  const have = new Set(combat.combatants.map(c => c.tokenId));
  const rows = tokens.filter(t => !have.has(t.id)).map(t => ({ tokenId: t.id, sceneId: scene.id, actorId: t.actorId, hidden: t.hidden }));
  if (rows.length) await combat.createEmbeddedDocuments("Combatant", rows);
  if (!combat.active) await combat.activate();
  return combat;
}
function pcCardHTML(p) {
  const row = (k, v) => v || v === 0 ? `<tr><th>${esc(k)}</th><td>${md(v)}</td></tr>` : "";
  return `<table>${row("Sınıf", [p.hcls || p.cls, p.prest].filter(Boolean).join(" · "))}${row("Halk", p.halk)}${row("Köken", [p.origin, p.city].filter(Boolean).join(" · "))}${row("Seviye", p.level)}${row("Kaçınma", p.evasion)}${row("HP", `${p.hp}/${p.hpMax} işaretli`)}${row("Stres", `${p.st}/${p.stMax}`)}${row("Umut", p.hope)}${row("Zırh", `${p.ar}/${p.arMax}`)}${row("Eşikler", `${p.major}/${p.severe}`)}${row("Anı Puanı", p.ap)}${row("Emanet", p.relic)}${row("Meslekler", (p.profs || []).join(", "))}${row("Yaralar", (p.wounds || []).map(w => typeof w === "string" ? w : w.n || w.name || "").filter(Boolean).join(", "))}</table>${para(p.note)}`;
}

/* ---------- siteden gelen olaylar ---------- */
const HANDLERS = {
  async roll(p) {
    if (setting("rollsToChat") === false) return { atlandi: "Foundry ayarlarında kapalı" };
    const d = p.dual;
    let html = `<div class="hib-chat"><div class="hib-chat-h">Hibernia GM Ekranı</div><div class="hib-chat-t">${esc(p.text)}</div>`;
    if (d) {
      const res = d.hope === d.fear ? "Kritik" : d.hope > d.fear ? "Umutla" : "Korkuyla";
      html += `<div class="hib-dual"><span class="hope">Umut ${esc(d.hope)}</span><span class="fear">Korku ${esc(d.fear)}</span>${d.mod ? `<span>${d.mod > 0 ? "+" : ""}${esc(d.mod)}</span>` : ""}<b>${esc(d.total)}</b><em>${res}</em></div>`;
    }
    html += `</div>`;
    const whisper = p.gizli ? game.users.filter(u => u.isGM).map(u => u.id) : [];
    await ChatMessage.implementation.create({ content: html, speaker: { alias: "GM Ekranı" }, whisper, flags: { [MOD]: { fromSite: true } } });
    if (d && game.dice3d && setting("dice3d") !== false) {
      try {
        const r = await new Roll("1d12 + 1d12").evaluate();
        r.dice[0].results = [{ result: int(d.hope, 1), active: true }]; r.dice[1].results = [{ result: int(d.fear, 1), active: true }];
        game.dice3d.showForRoll(r, game.user, true, whisper.length ? whisper : null, !!p.gizli);
      } catch (e) { /* 3B zar isteğe bağlı */ }
    }
    return { ozet: p.text };
  },
  async show_image(p) {
    const src = await toFoundry({ path: p.path, url: p.path ? null : p.url }, "resim", imgName(p.key, p.path || p.url));
    await showImage(src, p.title);
    return { ozet: p.title, path: src };
  },
  async encounter(p) {
    const units = p.units || [];
    if (!units.length) return { atlandi: "birim yok" };
    const byBase = new Map();
    for (const u of units) if (!byBase.has(u.base || u.name)) byBase.set(u.base || u.name, await upsertCreature(u, "Hibernia · Düşmanlar"));
    const scene = canvas?.scene;
    let tokens = [];
    if (p.tokens !== false && scene) tokens = await placeTokens(scene, units.map(u => ({ u, actor: byBase.get(u.base || u.name) })));
    if (p.combat !== false && tokens.length) await addToCombat(scene, tokens);
    const ozet = `${p.name || "Karşılaşma"}: ${byBase.size} aktör, ${tokens.length} jeton${scene ? " · " + scene.name : " (açık sahne yok)"}`;
    note(ozet);
    return { ozet, actors: byBase.size, tokens: tokens.length, scene: scene?.name || null };
  },
  async actors(p) {
    if (p.npc) {
      const n = p.npc;
      const desc = [n.role, n.city && `Şehir: ${n.city}`, n.org && `Örgüt: ${n.org}`, n.halk && `Halk: ${n.halk}`, n.cls && `Sınıf: ${n.cls}`, n.look && `Görünüş: ${n.look}`, n.table && `Masada: ${n.table}`, n.page && `Kitap s.${n.page}`].filter(Boolean).join("\n\n");
      const notesHTML = `${n.hooks?.length ? `<h3>Kancalar</h3>${n.hooks.map(para).join("")}` : ""}${n.secrets?.length ? `<h3>Sırlar (yalnızca GM)</h3>${n.secrets.map(para).join("")}` : ""}${para(n.note)}`;
      if (n.stat) {
        const s = n.stat;
        const a = await upsertCreature({ src: "npc", key: n.key, img: n.img, name: n.name, base: n.name, tier: s.tier, type: s.type, diff: s.diff, mj: s.mj, sv: s.sv, hp: s.hp, st: s.st, atk: s.atk, wpn: s.wpn, rng: s.rng, dmg: s.dmg, exp: s.exp, feats: s.feats, desc, notesHTML }, "Hibernia · NPC'ler");
        return { ozet: `${a.name} (stat bloklu)` };
      }
      const folder = await ensureFolder("Hibernia · NPC'ler", "Actor");
      const img = await imgFor(n);
      const key = "npc:" + n.id;
      let actor = game.actors.find(x => x.getFlag(MOD, "key") === key);
      const data = { name: n.name, img: img || undefined };
      if (isDH() && hasType("Actor", "npc")) data.system = { description: para(desc), motives: n.table || "", notes: notesHTML };
      if (img) data.prototypeToken = { texture: { src: img } };
      if (actor) await safeUpdate(actor, data);
      else actor = await safeCreate(Object.assign(data, { type: hasType("Actor", "npc") ? "npc" : "adversary", folder: folder.id, flags: { [MOD]: { key } },
        prototypeToken: Object.assign({ name: n.name, disposition: CONST.TOKEN_DISPOSITIONS.NEUTRAL }, img ? { texture: { src: img } } : {}) }));
      if (!isDH()) { const j = await ensureJournal("Hibernia · NPC'ler"); await upsertPage(j, n.name, { type: "text", text: { content: para(desc) + notesHTML, format: 1 } }); }
      return { ozet: actor.name };
    }
    const pcs = p.pcs || [];
    const folder = await ensureFolder("Hibernia · Oyuncular", "Actor");
    const j = await ensureJournal("Hibernia · Oyuncu kartları");
    let made = 0, kept = 0;
    for (const pc of pcs) {
      await upsertPage(j, pc.name, { type: "text", text: { content: pcCardHTML(pc), format: 1 } });
      const mine = game.actors.find(a => a.getFlag(MOD, "key") === pc.key);
      const theirs = !mine && game.actors.find(a => a.type === "character" && a.name === pc.name);
      if (theirs) { kept++; continue; } // oyuncunun kendi kâğıdına dokunma
      const img = await imgFor(pc);
      const data = { name: pc.name, img: img || undefined };
      if (isDH()) data.system = { biography: { background: pcCardHTML(pc) }, resources: { hitPoints: { value: int(pc.hp), max: int(pc.hpMax, 6) }, stress: { value: int(pc.st), max: int(pc.stMax, 6) }, hope: { value: int(pc.hope, 2) } } };
      if (img) data.prototypeToken = { texture: { src: img } };
      if (mine) await safeUpdate(mine, data);
      else { await safeCreate(Object.assign(data, { type: hasType("Actor", "character") ? "character" : Object.keys(CONFIG.Actor?.dataModels || { npc: 1 })[0], folder: folder.id, flags: { [MOD]: { key: pc.key } },
        prototypeToken: Object.assign({ name: pc.name, disposition: CONST.TOKEN_DISPOSITIONS.FRIENDLY, actorLink: true }, img ? { texture: { src: img } } : {}) })); made++; }
    }
    const ozet = `${pcs.length} oyuncu kartı günlüğe yazıldı · ${made} yeni aktör${kept ? ` · ${kept} var olan karakter kâğıdına dokunulmadı` : ""}`;
    note(ozet);
    return { ozet, made, kept };
  },
  async file(p) {
    const kind = p.kind || "dosya";
    const sub = { resim: "resim", harita: "harita", ses: "ses", belge: "belge", karakter: "karakter", foundry: "geri" }[kind] || "dosya";
    const name = safe(String(p.path || p.name).split("/").pop());
    const action = p.action || "dosya";
    if (action === "aktor") {
      const blob = await storageBlob(p.path);
      let data; try { data = JSON.parse(await blob.text()); } catch (e) { throw new Error("dosya geçerli bir Foundry JSON'u değil"); }
      if (!data || !data.type || !data.name) throw new Error("dosyada aktör bilgisi yok");
      for (const k of ["_id", "folder", "ownership", "_stats", "sort"]) delete data[k];
      const folder = await ensureFolder("Hibernia · Gelen aktörler", "Actor");
      data.folder = folder.id;
      const a = await Actor.implementation.create(data);
      return { ozet: `${a.name} içe aktarıldı` };
    }
    const path = await toFoundry({ path: p.path }, sub, name);
    const ext = name.split(".").pop().toLowerCase();
    const isImg = /^(png|jpe?g|webp|gif|avif|svg)$/.test(ext), isVid = /^(webm|mp4|m4v)$/.test(ext);
    const title = showName(p.name || name).replace(/\.[^.]+$/, "");
    if (action === "goster" && (isImg || isVid)) { await showImage(path, title); return { ozet: title + " gösterildi", path }; }
    if (action === "sahne" || action === "sahne_ac") {
      const dim = await mediaSize(path, isVid);
      const sc = await Scene.implementation.create({ name: title, background: { src: path }, width: dim.w || 3000, height: dim.h || 2000, padding: 0.05, navigation: true });
      try { if (gen() >= 14 && sc.initialLevel && !sc.initialLevel.background?.src) await sc.initialLevel.update({ "background.src": path }); } catch (e) {}
      if (action === "sahne_ac") await sc.activate();
      return { ozet: `Sahne: ${title}${action === "sahne_ac" ? " (açıldı)" : ""}`, path };
    }
    if (action === "liste" || action === "cal") {
      const pl = game.playlists.find(x => x.name === "Hibernia") || await Playlist.implementation.create({ name: "Hibernia", mode: CONST.PLAYLIST_MODES?.DISABLED ?? -1 });
      const [snd] = await pl.createEmbeddedDocuments("PlaylistSound", [{ name: title, path, volume: 0.5, repeat: false }]);
      if (action === "cal") await pl.playSound(snd);
      return { ozet: `Çalma listesi: ${title}${action === "cal" ? " (çalıyor)" : ""}`, path };
    }
    if (action === "gunluk") {
      const jn = await ensureJournal("Hibernia · Gelen dosyalar");
      let page;
      if (isImg) page = { type: "image", src: path, image: { caption: title } };
      else if (ext === "pdf") page = { type: "pdf", src: path };
      else if (isVid) page = { type: "video", src: path };
      else if (/^(txt|md|html?)$/.test(ext)) { const txt = await (await storageBlob(p.path)).text(); page = { type: "text", text: { content: /^html?$/.test(ext) ? txt : para(txt), format: 1 } }; }
      else page = { type: "text", text: { content: `<p>Dosya: <a href="${esc(path)}">${esc(name)}</a></p>`, format: 1 } };
      await upsertPage(jn, title, page);
      return { ozet: `Günlük: ${title}`, path };
    }
    return { ozet: `Yüklendi: ${path}`, path };
  },
  async fear(p) {
    if (setting("fearSync") === false) return { atlandi: "Foundry ayarlarında kapalı" };
    if (!isDH()) return { atlandi: "Daggerheart sistemi değil" };
    const v = clamp(int(p.value, 0), 0, 99);
    if (int(game.settings.get("daggerheart", "ResourcesFear"), -1) === v) return { ozet: "Korku zaten " + v };
    H.fearFromSite = v;
    await game.settings.set("daggerheart", "ResourcesFear", v);
    return { ozet: "Korku " + v };
  }
};
function mediaSize(src, video) {
  return new Promise(res => {
    const done = (w, h) => res({ w: w || 0, h: h || 0 });
    if (video) { const v = document.createElement("video"); v.onloadedmetadata = () => done(v.videoWidth, v.videoHeight); v.onerror = () => done(); v.src = src; }
    else { const i = new Image(); i.onload = () => done(i.naturalWidth, i.naturalHeight); i.onerror = () => done(); i.src = src; }
    setTimeout(() => done(), 8000);
  });
}

/* ---------- Foundry'den siteye ---------- */
async function uploadToSite(blob, folder, name) {
  const sp = `${H.uid}/${folder}/${Date.now().toString(36)}-${safe(name)}`;
  const { error } = await H.sb.storage.from(BUCKET).upload(sp, blob, { contentType: blob.type || "application/octet-stream", upsert: false });
  if (error) throw new Error(error.message);
  return sp;
}
async function sendFoundryFile(path) {
  if (!H.uid) return note("Önce giriş yap.", "warn");
  const res = await fetch(path); if (!res.ok) return note("Dosya okunamadı: " + path, "error");
  const blob = await res.blob();
  const name = decodeURIComponent(String(path).split("?")[0].split("/").pop());
  const sp = await uploadToSite(blob, "files/foundry", name);
  await send("file", { name, path: sp, kind: "foundry" });
  note(name + " siteye gönderildi.");
}
function attackFormula(atk) {
  try {
    const d = atk?.damage; const part = d?.main || (d?.parts && Object.values(d.parts)[0]);
    const v = part?.value; if (!v) return "";
    const f = typeof v.getFormula === "function" ? v.getFormula() : v.custom?.enabled ? v.custom.formula : `${v.flatMultiplier ?? 1}${v.dice}${v.bonus ? (v.bonus > 0 ? "+" : "") + v.bonus : ""}`;
    const types = part.type instanceof Set ? [...part.type] : part.type || [];
    return f + (types.includes?.("magical") ? " mag" : " phy");
  } catch (e) { return ""; }
}
async function sendActor(actor) {
  if (!H.uid) return note("Önce Hibernia penceresinden giriş yap.", "warn");
  const sys = actor.system || {};
  let img = null;
  if (actor.img && !/^icons\/|mystery-man|\.svg(\?|$)/i.test(actor.img)) {
    try { const blob = await (await fetch(actor.img)).blob(); const ext = (blob.type.split("/")[1] || "webp").replace("jpeg", "jpg").replace(/[^a-z0-9]/g, ""); img = await uploadToSite(blob, "img", "aktor." + ext); } catch (e) { console.warn(MOD, e); }
  }
  let json = null;
  try { const obj = actor.toCompendium ? actor.toCompendium(null, { clearSort: true, clearFolder: true, clearOwnership: true }) : actor.toObject(); json = await uploadToSite(new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" }), "files/foundry", actor.name + ".json"); } catch (e) { console.warn(MOD, e); }
  const dh = isDH() ? {
    tier: sys.tier, type: sys.type, difficulty: sys.difficulty, hp: sys.resources?.hitPoints?.max, stress: sys.resources?.stress?.max,
    mj: sys.damageThresholds?.major, sv: sys.damageThresholds?.severe, evasion: sys.evasion,
    atk: sys.attack?.roll?.bonus != null ? (sys.attack.roll.bonus >= 0 ? "+" : "") + sys.attack.roll.bonus : undefined, wpn: sys.attack?.name, dmg: attackFormula(sys.attack),
    feats: actor.items.filter(i => i.type === "feature").map(i => [i.name, i.system?.featureForm || "", strip(i.system?.description || "").slice(0, 600)])
  } : null;
  const bio = strip(sys.biography?.background || sys.description || sys.notes || sys.details?.biography?.value || "").slice(0, 2000);
  const r = await send("actor", { name: actor.name, type: actor.type, img, bio, dh, json });
  if (r) note(actor.name + " siteye gönderildi.");
}

/* ---------- pencere ---------- */
function defineApp() {
  const AppV2 = foundry.applications.api.ApplicationV2;
  return class HibApp extends AppV2 {
    constructor(options = {}) { if (H.app) return H.app; super(options); H.app = this; }
    static DEFAULT_OPTIONS = { id: "hibernia-gm-baglanti", classes: ["hib-app"], tag: "section", window: { title: "Hibernia GM Bağlantısı", icon: "fas fa-link", resizable: true }, position: { width: 470, height: "auto" } };
    static open() { const a = H.app || new HibApp(); a.render({ force: true }); return a; }
    refresh() { if (this.rendered) this.render(); }
    async _renderHTML() {
      const on = H.state === "bağlı";
      const leader = isLeader(), gm = game.users.activeGM;
      const st = { "bağlı": "Bağlı", "giriş gerekli": "Giriş gerekli", "bağlanıyor": "Bağlanıyor…", "kapalı": "Kapalı", "hata": "Hata", "bağlantı sorunu": "Bağlantı sorunu" }[H.state] || H.state;
      let h = `<div class="hib"><p class="hib-st"><span class="hib-dot ${on ? "on" : ""}"></span><b>${esc(st)}</b>${H.email ? ` · ${esc(H.email)}` : ""}</p>${H.err ? `<p class="hib-err">${esc(H.err)}</p>` : ""}`;
      if (!H.uid) {
        h += `<form class="hib-login"><label>E-posta<input type="email" name="email" autocomplete="username" required></label><label>Şifre<input type="password" name="pw" autocomplete="current-password" required></label><button type="submit"><i class="fas fa-right-to-bracket"></i> Giriş yap</button></form>
          <p class="hib-hint">Web sitesindeki e-posta ve şifrenle aynı. Yalnızca GM girer; oyuncuların bir şey yapmasına gerek yok.</p>`;
      } else {
        if (!leader) h += `<p class="hib-hint">Siteden gelenleri şu an etkin GM işliyor${gm ? ": " + esc(gm.name) : ""}.</p>`;
        h += `<div class="hib-row"><button type="button" data-a="fp"><i class="fas fa-folder-open"></i> Foundry'den siteye dosya</button><button type="button" data-a="pc"><i class="fas fa-upload"></i> Bilgisayardan siteye dosya</button><input type="file" multiple hidden></div>
          <div class="hib-row"><button type="button" data-a="sync"><i class="fas fa-rotate"></i> Bekleyenleri işle</button><button type="button" data-a="out"><i class="fas fa-right-from-bracket"></i> Çıkış</button></div>
          <p class="hib-hint">Bir aktörü siteye göndermek için Aktörler listesinde ona sağ tıkla › "Hibernia ekranına gönder".</p>`;
      }
      h += `<h3>Son olaylar</h3>${H.log.length ? `<ol class="hib-log">${H.log.map(l => `<li class="${l.ok ? "" : "bad"}"><time>${esc(l.t)}</time><span>${l.dir === "giriş" ? "Site → Foundry" : "Foundry → Site"}</span><b>${esc(KIND_TR[l.kind] || l.kind)}</b><em>${esc(l.text)}</em></li>`).join("")}</ol>` : `<p class="hib-hint">Henüz bir şey gelmedi.</p>`}</div>`;
      return h;
    }
    _replaceHTML(result, content) {
      content.innerHTML = result;
      const f = content.querySelector("form.hib-login");
      if (f) f.addEventListener("submit", async ev => {
        ev.preventDefault();
        const btn = f.querySelector("button"); btn.disabled = true; H.err = "";
        try {
          const sb = await client();
          const { data, error } = await sb.auth.signInWithPassword({ email: f.email.value.trim(), password: f.pw.value });
          if (error) { setState("giriş gerekli", /invalid/i.test(error.message) ? "E-posta ya da şifre yanlış." : error.message); return; }
          await start(data.user); note("Siteye bağlandı.");
        } catch (e) { setState("hata", e.message || String(e)); }
        finally { btn.disabled = false; }
      });
      content.querySelectorAll("[data-a]").forEach(b => b.addEventListener("click", async () => {
        const a = b.dataset.a;
        if (a === "out") { try { await H.sb.auth.signOut(); } catch (e) {} stop("giriş gerekli"); }
        else if (a === "sync") { H.done.clear(); processPending(); }
        else if (a === "fp") { const P = FP(); new P({ type: "any", callback: p => sendFoundryFile(p).catch(e => note(e.message, "error")) }).render(true); }
        else if (a === "pc") { const inp = content.querySelector("input[type=file]"); inp.onchange = async () => { for (const fl of inp.files) { try { const sp = await uploadToSite(fl, "files/foundry", fl.name); await send("file", { name: fl.name, path: sp, kind: "foundry" }); } catch (e) { note(e.message, "error"); } } note(inp.files.length + " dosya siteye gönderildi."); inp.value = ""; }; inp.click(); }
      }));
    }
    _onClose(options) { super._onClose?.(options); }
  };
}

/* ---------- kancalar ---------- */
let HibApp = null;
Hooks.once("init", () => {
  const reg = (k, o) => game.settings.register(MOD, k, Object.assign({ scope: "world", config: true }, o));
  reg("url", { name: "Site sunucu adresi", hint: "Supabase proje adresi. Değiştirmen gerekmez.", type: String, default: DEF_URL, requiresReload: true });
  reg("key", { name: "Site anahtarı (publishable)", hint: "Herkese açık anahtar. Gizli (secret/service_role) anahtarı buraya asla yazma.", type: String, default: DEF_KEY, requiresReload: true });
  reg("folder", { name: "Dosya klasörü", hint: "Siteden gelen resim, harita, ses ve belgelerin Foundry veri klasöründeki yeri.", type: String, default: "hibernia" });
  reg("source", { name: "Dosya kaynağı", hint: "Otomatik: The Forge'da forgevtt, diğer sunucularda data.", type: String, default: "auto", choices: { auto: "Otomatik", data: "Kullanıcı verisi (data)", forgevtt: "The Forge", s3: "S3" } });
  reg("rollsToChat", { name: "Siteden gelen zarları sohbete yaz", type: Boolean, default: true });
  reg("dice3d", { name: "Dualite zarlarını Dice So Nice ile göster", type: Boolean, default: true });
  reg("rollsToSite", { name: "Foundry zarlarını siteye gönder", type: Boolean, default: true });
  reg("fearSync", { name: "Korku havuzunu eşitle", hint: "Daggerheart sistemindeki Korku ile sitedeki Korku havuzu aynı kalır.", type: Boolean, default: true });
  HibApp = defineApp();
  game.settings.registerMenu(MOD, "panel", { name: "Hibernia bağlantı penceresi", label: "Pencereyi aç", hint: "Giriş, dosya gönderme ve son olaylar.", icon: "fas fa-link", type: HibApp, restricted: true });
  game.modules.get(MOD).api = { open: () => HibApp.open(), sendActor, sendFoundryFile, connect, state: () => ({ ...H }) };
});
Hooks.once("ready", async () => {
  if (!game.user.isGM) return;
  await connect();
  if (H.state === "giriş gerekli" && isLeader()) note("Siteyle bağlantı için Ayarlar › Hibernia GM Bağlantısı'ndan giriş yap.", "warn");
});
Hooks.on("userConnected", () => { if (H.uid && isLeader()) { heartbeat(); processPending(); } });
Hooks.on("canvasReady", () => { if (H.uid) heartbeat(); });

Hooks.on("createChatMessage", msg => {
  if (!H.uid || !isLeader() || setting("rollsToSite") === false) return;
  if (msg.getFlag?.(MOD, "fromSite")) return;
  const roll = msg.rolls?.[0]; if (!roll) return;
  const payload = { speaker: msg.speaker?.alias || msg.alias || msg.author?.name || "", formula: roll.formula, total: roll.total,
    flavor: strip(msg.flavor || msg.system?.title || roll.options?.title || "").slice(0, 120), gizli: !!(msg.whisper?.length || msg.blind) };
  try { if (roll.dHope && roll.dFear && roll.dHope.total != null) payload.dual = { hope: roll.dHope.total, fear: roll.dFear.total, crit: !!roll.isCritical }; } catch (e) {}
  send("roll", payload);
});
Hooks.on("updateSetting", setting => {
  if (setting.key !== "daggerheart.ResourcesFear" || !H.uid || !isLeader() || game.settings.get(MOD, "fearSync") === false) return;
  clearTimeout(H.fearTimer);
  H.fearTimer = setTimeout(() => {
    const v = int(game.settings.get("daggerheart", "ResourcesFear"), 0);
    if (H.fearFromSite === v) { H.fearFromSite = null; return; }
    H.fearFromSite = null; send("fear", { value: v });
  }, 350);
});
function actorMenu(options) {
  if (options.some(o => (o.label || o.name) === "Hibernia ekranına gönder")) return;
  const getId = el => { const e = el instanceof HTMLElement ? el : el?.[0]; return e?.dataset?.entryId || e?.dataset?.documentId; };
  const run = el => { const a = game.actors.get(getId(el)); if (a) sendActor(a).catch(e => note(e.message, "error")); };
  if (gen() >= 14) options.push({ label: "Hibernia ekranına gönder", icon: '<i class="fas fa-share-from-square"></i>', visible: () => game.user.isGM, onClick: (ev, target) => run(target) });
  else options.push({ name: "Hibernia ekranına gönder", icon: '<i class="fas fa-share-from-square"></i>', condition: () => game.user.isGM, callback: li => run(li) });
}
Hooks.on("getActorContextOptions", (app, options) => actorMenu(options));
Hooks.on("getActorDirectoryEntryContext", (html, options) => actorMenu(options));
Hooks.on("renderSettings", (app, html) => {
  if (!game.user.isGM) return;
  const root = html instanceof HTMLElement ? html : html?.[0]; if (!root || root.querySelector(".hib-open")) return;
  const b = document.createElement("button"); b.type = "button"; b.className = "hib-open";
  b.innerHTML = `<i class="fas fa-link"></i> Hibernia GM Bağlantısı`;
  b.addEventListener("click", () => HibApp?.open());
  const anchor = root.querySelector("section.settings") || root.querySelector("#settings-game") || root.querySelector("section") || root;
  anchor.append(b);
});
